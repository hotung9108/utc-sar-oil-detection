# Bản báo cáo để nhóm rà soát

- [Bản Word v9](Bao_cao_SAR_SOS_review_v9.docx)
- [Bản PDF v9](Bao_cao_SAR_SOS_review_v9.pdf)

Bản v9 có 38 trang tổng cộng, 26 trang nội dung chính, 13 tài liệu tham khảo. Đã bổ sung Bảng 4.4: mô hình SOS báo nhầm 1.449/2.290 ảnh no-oil DARTIS (63,2751%); cập nhật kiểm tra kích thước đủ 41 cặp QPOSD và đọc đầy đủ mẫu 41. Các số đo SOS giữ nguyên.

Đã kiểm tra mục lục và bố cục theo `docs/report/render_audit.json` và `render_progress.json`: xem trực tiếp hai trang thay đổi (7, 33), 36 trang còn lại giống pixel với bản v8 đã duyệt. Hai tệp v9 giữ nguyên byte của bản được kiểm tra; v8 được giữ để đối chiếu lịch sử.

**Đây chưa phải bản nộp hoàn chỉnh.** Cần thông tin lớp, giảng viên, nhóm, mã sinh viên, xác nhận đóng góp và biên bản họp thật. Nội dung cũng ghi rõ: chưa kiểm chứng phát hiện dầu trên tile đã hiệu chuẩn, chưa đánh giá nhầm lẫn theo từng nguyên nhân look-alike, nhánh Niblack chưa có test độc lập mới.

Nguồn dựng: `docs/report/narrative.json`, `bibliography.json`, `scripts/build_report.py`; quy trình dựng và cập nhật trường tại `docs/report/README.md`. Hướng dẫn GUI tại `docs/DEMO_GUI.md`, video tại `deliverables/video/README.md`. Không chỉnh trực tiếp PDF để thay số liệu hoặc mục lục; cần dựng và kiểm tra lại sau sửa.
